# TouchSim

TouchSim is a simulation of the responses of every afferent innervating the glabrous skin of the hand. The model is described in detail in a paper entitled “Simulating tactile signals from the whole hand with millisecond precision” (Saal, Delhaye, Rayhaun, and Bensmaia, PNAS, 2017).

This software was developed at [BensmaiaLab](https://www.bensmaialab.github.io/)
